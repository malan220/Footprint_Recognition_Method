function [km_r,F2,max_x,min_x,max_y,min_y] = km(K,i)
I = [K(1:2,:)]';
%KMEANS
% % % % [F,CC]=imkmeans2(I,i);
alpha = 0.5;
i_re = 0;S
beta1 = ones(1,i)*100;
beta2 = ones(1,i)*100;
% while alpha>0.36 | any(beta1<38) | any(beta1>65) | any(beta2<7) | any(beta2>35)
while alpha>0.7 | any(beta1<30) | any(beta1>65) | any(beta2<7) | any(beta2>40)
    F = kmedoids(I,i);
    % %%GAOSI
    % GMModel = fitgmdist(I,i);
    % F = cluster(GMModel,I);
    F2 = F;
    CCC = [];
%     CCC2=[];
%     for iii=1:i
%         CCC2(iii,:)=length(find(F==iii));
%     end
%     %         [B,IX] = sort(CCC2,1);
%     [B,IX] = sort(CCC2,1,'descend');
%     for iiii=1:i
%         F2(F==iiii) = IX(iiii,1);
%         IX(iiii,1);
%     end
    for iii=1:i
        CCC(iii,:)=mean(I(F2==iii,:),1);
%         max_x(iii) = max(K(1,F2==iii));
%         min_x(iii) = min(K(1,F2==iii));
%         max_y(iii) = max(K(2,F2==iii));
%         min_y(iii) = min(K(2,F2==iii));
    end
    %%%%
    [B,IX] = sort(CCC,1);
    B2 = diff(B(:,1));
    B2_max = max(B2);
    B2_min = min(B2);
    for iiii=1:i
%         F2(F==iiii) = IX(iiii,1);
        F2(F==iiii) = find(IX(:,1)==iiii);
        IX(iiii,1);
    end
    alpha = abs(abs(B2_max/B2_min)-1);
    for iii=1:i
        max_x(iii) = max(K(1,F2==iii));
        min_x(iii) = min(K(1,F2==iii));
        max_y(iii) = max(K(2,F2==iii));
        min_y(iii) = min(K(2,F2==iii));
    end
    %         alpha = 0.1
    beta1 = max_x-min_x;
    beta2 = max_y-min_y;
    i_re=i_re+1;
    if i_re>55
        break
    end
end
if i_re==56
    km_r=0;
else
    km_r=1;
end

