%%%获取足印
% function DD = load_dynamic96(path)  %整个压力矩阵
function [DDDDDD,i3] = load_dynamic96(path)  %整个压力矩阵
tt  ='.\全部图片\ne';
tt22  ='.\全部图片\new';
file_id = fopen(path);
C = textscan(file_id, '%s', 'Delimiter', ',', 'HeaderLines', 1);
fclose(file_id);
%%%%
[pathstr,name,ext]=fileparts(path);
[pathstr2,name2,ext2]=fileparts(pathstr);
path22 = [name2,name];
path2 = [tt,path22];
path3 = [tt22,path22];
%%%%
DD = [];
dra= 16;
drb = 375;
D = C{1,1}(dra:drb);
d1size=size(D{1},2);
D{1} = D{1}(5:d1size);
a = size(D,1);
b = zeros(a,100);
for i=1:a
    bb = textscan(D{i}, '%d', 'Delimiter', ';');
    b(i,:) = cell2mat(bb)';
end
DD(:,:) = b;
k = find(b~=0);
[k1,k2] = find(b~=0);
K=[k1,k2,b(k)]';
figure(1)            % 新建一个句柄为2的图形窗口。
% subplot(i2+2,1,1)
scatter(K(1,:),K(2,:),[],K(3,:),'filled','s'); %filled表示填充圆圈
axis equal
axis([0 360 0 100]);
print(1,'-djpeg',path3);
%% 初始聚类
for i=2:5
    i;
    [km_r,F2,max_x,min_x,max_y,min_y] = km2(K,i);
    if km_r == 1
        break
    end
end
%% 判断边界是否有数值
km_r2 = 0;
if max(max_x)>=350 | min(min_x)<=4
    if max(max_x) >= 350
        F2(F2==i) = 0;
    end
    if min(min_x) <=4
        F2(F2==1) = 0;
    end
%     indexf = find(F2~=0);
    K2 = K(:,F2~=0);
    for i2=2:5
        F3 = [];
        [km_r2,F3,max_x,min_x,max_y,min_y] = km(K2,i2);
        if km_r2 == 1
            figure(2)            % 新建一个句柄为2的图形窗口。
            subplot(i2+2,1,1)
            scatter(K(1,:),K(2,:),[],K(3,:),'filled','s'); %filled表示填充圆圈
            axis equal
            axis([0 360 0 100]);
            figure(2)            % 新建一个句柄为2的图形窗口。
            subplot(i2+2,1,2)
%             s = ones(max(size(K2(3,:))),1)*30; %圆圈的大小
            % % scatter3(KK(1,:),KK(2,:),KK(3,:),s,KK(3,:),'filled','s'); %filled表示填充圆圈
            scatter(K2(1,:),K2(2,:),[],F3,'filled','s'); %filled表示填充圆圈
            axis equal
            axis([0 360 0 100]);
            for iii=1:i2
                subplot(i2+2,1,iii+2)            %新建一个句柄为2的图形窗口。
                scatter(K2(1,F3==iii),K2(2,F3==iii),[],K2(3,F3==iii),'filled','s'); %filled表示填充圆圈
                axis equal
                axis([0 360 0 100]);
            end
%             grid
            print(2,'-djpeg',path2);
            break
        end
    end
else
    figure(2)            % 新建一个句柄为2的图形窗口。
    subplot(i+2,1,1)
    scatter(K(1,:),K(2,:),[],K(3,:),'filled','s'); %filled表示填充圆圈
    axis equal
    axis([0 360 0 100]);
    figure(2)            % 新建一个句柄为2的图形窗口。
    % plot(x,cos(x));    % 在句柄为2的图形窗口上画图。
    subplot(i+2,1,2)
    scatter(K(1,:),K(2,:),[],F2,'filled','s'); %filled表示填充圆圈
    axis equal
    axis([0 360 0 100]);
    for iii=1:i
        subplot(i+2,1,iii+2)            %新建一个句柄为2的图形窗口。
        scatter(K(1,F2==iii),K(2,F2==iii),[],K(3,F2==iii),'filled','s');
        axis equal
        axis([0 360 0 100]);
    end
%     grid
    print(2,'-djpeg',path2);
end
%% DDDDD赋值
DDDDD=[];
if km_r2 == 1
    i3 = i2;
    DDDDD=[K2;F3'];
    for i4=1:i3
        DDDDDD{i4}=K2(:,F3==i4);
    end    
else 
    i3 = i;
    DDDDD=[K;F2'];
    for i4=1:i3
        DDDDDD{i4}=K(:,F2==i4);
    end
end
