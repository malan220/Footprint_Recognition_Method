close all;
clc;
current_location=pwd;  %currentFolder=pwd表示将当前路径以字符向量形式返回，存在currentFolder变量
Path = '\raw_data\';         % 设置数据存放的文件夹路径
mts = readcsv_dynamic(Path);                                               % 加载
%%%
mts.h1 = [mts1.h1,mts2.h1];
mts.count = [mts1.count,mts2.count];
mts.outlisting = [mts1.outlisting;mts2.outlisting];
mts.count2=[0];
for i=1:size(mts.count,2)
    mts.count2=[mts.count2,mts.count2(size(mts.count2,2))+ mts.count(i)];
end
%%%存所有数据
tt=sprintf('Footprint');
% tt=sprintf('pdzddy_all_matk');
save(tt,'mts');

