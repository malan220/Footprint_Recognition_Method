import torch
print('当前使用的pytorch版本：', torch.__version__)
from utils.random_seed import setup_seed
from torch.utils.data import DataLoader
from dataset_process.dataset_process import MyDataset
# from utils.heatMap import heatMap_all
from utils.heatMap import heatMap_all_half
from utils.heatMap import heatMap_all2
from utils.TSNE import gather_by_tsne
from utils.TSNE import gather_all_by_tsne
from utils.TSNE import gather_all_by_tsne2
from utils.TSNE import gather_all_by_lle
import numpy as np
from utils.colorful_line import draw_colorful_line
# from utils.draw_scatter import draw_scatter
# from utils.draw_scatter import draw_scatter_2d
# from utils.draw_scatter import draw_scatter_2d_score_max
# from utils.draw_scatter import draw_scatter_2d_score_avr
# from utils.draw_scatter import draw_scatter_2d_score_all
from utils.draw_scatter import draw_scatter_2d_score_all2
# from utils.draw_scatter import draw_scatter_2d_score_all_max
# from utils.draw_scatter import draw_scatter_2d_score_all_ave
# from utils.draw_scatter import draw_scatter_3d_score_max
# from utils.draw_scatter import draw_scatter_3d_score_avr
# from utils.draw_line import draw_mts
# from utils.draw_line import draw_heatmap_anylasis2
# from utils.draw_line import draw_heatmap_anylasis3

from utils.draw_line import draw_mts3
from utils.random_seed import setup_seed

import matplotlib.pyplot as plt
setup_seed(30)
# DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
DEVICE = torch.device("cpu")
save_model_path = 'saved_model/top/pindices4a_zuizhong_pdzddy_newlr_withoutpooling_fold5std0_3 97.96.pkl'

# save_model_path = 'saved_model/ECG 91.0 batch=2.pkl'
file_name = save_model_path.split('/')[-1].split(' ')[0]
# path = f'E:\PyCharmWorkSpace\\dataset\\MTS_dataset\\{file_name}\\{file_name}.mat'  # 拼装数据集路径
path = f'E:\PyCharmWorkSpace\\dataset\\MTS_dataset\\pkzd2\\{file_name}.mat'  # 拼装数据集路径
# 绘制HeatMap的命名准备工作
ACCURACY = save_model_path.split('/')[-1].split(' ')[1]  # 使用的模型的准确率
#BATCH_SIZE = int(save_model_path[save_model_path.find('=')+1:save_model_path.rfind('.')])  # 使用的模型的batch_size
BATCH_SIZE = 1
# heatMap_or_not = False  # 是否绘制Score矩阵的HeatMap图
heatMap_or_not = True  # 是否绘制Score矩阵的HeatMap图
gather_or_not = False  # 是否绘制单个样本的step和channel上的聚类图
# gather_or_not = True  # 是否绘制单个样本的step和channel上的聚类图
# gather_all_or_not = True  # 是否绘制所有样本在特征提取后的聚类图
gather_all_or_not = False  # 是否绘制所有样本在特征提取后的聚类图
# mts_or_not = True
# 加载模型
net = torch.load(save_model_path, map_location=torch.device('cpu'))  # map_location 设置使用的设备，可能是因为原来的pkl是在colab上用GPU跑的


# 加载测试集数据
test_dataset = MyDataset(path, 'test')
# train_dataset = MyDataset(path, 'train')
test_dataloader = DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=False)
# train_dataloader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=False)

print(f'step为最大值的sample个数:{len(test_dataset.max_length_sample_inTest)}')
if len(test_dataset.max_length_sample_inTest) == 0:
    gather_or_not = False
    heatMap_or_not = False
    print('测试集中没有step为最大值的样本， 将不能绘制make sense 的heatmap 和 gather 图 可尝试换一个数据集')

correct = 0
total = 0
with torch.no_grad():
    all_sample_X = []
    all_sample_X_gather_input = []
    all_sample_X_encoding = []
    all_sample_X_gate = []
    all_sample_Y = []
    all_sample_Y_pre = []
    for x, y in test_dataloader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        y_pre, encoding, score_input, score_channel, gather_input, gather_channel, gate = net(x.to(DEVICE), 'test')
        # y_pre, post_fusion_y_1, score_input, score_channel,  gather_input, gather_channel, post_fusion_y_2 = net(x.to(DEVICE), 'test')
        # y_pre, post_fusion_y_1, score_input, score_channel, input_to_gather, channel_to_gather, post_fusion_y_2 = net(
        #     x.to(DEVICE), 'test')

        _, label_index = torch.max(y_pre.data, dim=-1)
        yyy_pre = label_index
        yyy_pre = yyy_pre.to(DEVICE)
        all_sample_Y_pre.append(yyy_pre)
        all_sample_Y.append(y)

        all_sample_X_gather_input.append(gather_input)
        all_sample_X_encoding.append(encoding)
        all_sample_X_gate.append(gate)


        # print("y,y_pre", y, yyy_pre)
        if heatMap_or_not:
            for index, sample in enumerate(test_dataset.max_length_sample_inTest):
                if index < 1:
                    if sample.numpy().tolist() in x.numpy().tolist():
                        target_index = x.numpy().tolist().index(sample.numpy().tolist())
                        # print('index：', index)
                        # print('正在绘制heatmap图...')
                        # heatMap_all_half(score_input[target_index], score_channel[target_index], sample,
                        #             'heatmap_figure_in_test', file_name, ACCURACY, index)
                        # print('heatmap图绘制完成！')
                        ##paper2
                        # print('正在绘制heatmap图...')
                        # heatMap_all2(score_input[target_index], score_channel[target_index], sample,
                        #             'heatmap_figure_in_test', file_name, ACCURACY, index)
                        # print('heatmap图绘制完成！')

                        # ##paper2
                        # print('正在绘制散点图...')
                        # ##画3d
                        # # draw_scatter(sample, file_name, index)
                        # #画足底压力
                        # draw_scatter_2d(sample, file_name, index)
                        # # for index_q in [0,1,2,3,4,5,25,50,72,73,74,75,76,77,78,79,100,125,150]:
                        # # for index_q in [0, 100, 200, 300, 400, 500]:
                        # # bb = range(243,247)
                        # # for index_q in bb:
                        # #     draw_scatter_2d_score_max(sample, file_name, index, score_input[target_index], index_q)
                        # #     draw_scatter_2d_score_avr(sample, file_name, index, score_channel[target_index], index_q)
                        ##整体左右画注意图
                        # bb = range(243, 247)
                        # bb = range(7, 17)
                        bb = range(0, 4)
                        # draw_scatter_2d_score_all(sample, file_name, index, score_input[target_index],
                        #                            score_channel[target_index], bb)    ####4个
                        draw_scatter_2d_score_all2(sample, file_name, index, score_input[target_index], score_channel[target_index], bb)
                        #
                        # ##分开平均和最大池化画注意图
                        # bb = range(0, 550, 60)
                        # draw_scatter_2d_score_all_max(sample, file_name, index, score_input[target_index], score_channel[target_index], bb)
                        # draw_scatter_2d_score_all_ave(sample, file_name, index, score_input[target_index],
                        #                           score_channel[target_index], bb)
                        #
                        # print('散点图绘制完成！')



        # if mts_or_not:
        #     for index, sample in enumerate(test_dataset.max_length_sample_inTest):
        #         if sample.numpy().tolist() in x.numpy().tolist():
        #             print('正在绘制mts图...')
        #             draw_mts(sample, file_name +' sample_mts')
        #             print('mts图绘制完成！')
        #             print('正在绘制heatmap_anylasis图...')
        #             draw_heatmap_anylasis2(sample, file_name +' sample_heatmap_anylasis')
        #             print('heatmap_anylasis图绘制完成！')

        if gather_or_not:
            for index, sample in enumerate(test_dataset.max_length_sample_inTest):
                if sample.numpy().tolist() in x.numpy().tolist():
                    target_index = x.numpy().tolist().index(sample.numpy().tolist())
                    print('正在绘制gather图...')
                    gather_by_tsne(gather_input[target_index].numpy(), np.arange(gather_input[target_index].shape[0]), index, file_name+' input_gather')
                    gather_by_tsne(gather_channel[target_index].numpy(), np.arange(gather_channel[target_index].shape[0]), index, file_name+' channel_gather')
                    print('gather图绘制完成！')
                    draw_data = x[target_index].transpose(-1, -2)[0].numpy()
                    draw_colorful_line(draw_data)
                    gather_or_not = False

        _, label_index = torch.max(y_pre.data, dim=-1)
        total += label_index.shape[0]
        correct += (label_index == y.long()).sum().item()

    if gather_all_or_not:
        all_sample_X_gather_input = torch.cat(all_sample_X_gather_input, dim=0).numpy()
        all_sample_X_gather_input = all_sample_X_gather_input.reshape(all_sample_X_gather_input.shape[0], -1)
        all_sample_X_encoding = torch.cat(all_sample_X_encoding, dim=0).numpy()
        all_sample_X_encoding = all_sample_X_encoding.reshape(all_sample_X_encoding.shape[0], -1)
        all_sample_X_gate = torch.cat(all_sample_X_gate, dim=0).numpy()
        all_sample_X_gate = all_sample_X_gate.reshape(all_sample_X_gate.shape[0], -1)
        # all_sample_X = torch.cat(all_sample_X, dim=0).numpy()
        # all_sample_X = all_sample_X.reshape(all_sample_X.shape[0], -1)
        all_sample_Y = torch.cat(all_sample_Y, dim=0).numpy()
        all_sample_Y_pre = torch.cat( all_sample_Y_pre, dim=0).numpy()
        print('正在绘制gather图...')
        setup_seed(30)
        # gather_all_by_tsne(all_sample_X, all_sample_Y, test_dataset.output_len, file_name+' all_sample_gather_row')
        # setup_seed(30)
        # gather_all_by_tsne(all_sample_X, all_sample_Y_pre, test_dataset.output_len, file_name + ' all_sample_gather_pre')
        # gather_all_by_lle(all_sample_X, all_sample_Y, test_dataset.output_len, file_name + ' all_sample_gather')
        gather_all_by_tsne2(all_sample_X_gather_input, all_sample_Y, all_sample_Y_pre, test_dataset.output_len, file_name + ' all_sample_gather_gatherinput')
        setup_seed(30)
        gather_all_by_tsne2(all_sample_X_encoding, all_sample_Y, all_sample_Y_pre, test_dataset.output_len,
                            file_name + ' all_sample_gather_encoding')
        setup_seed(30)
        gather_all_by_tsne2(all_sample_X_gate, all_sample_Y, all_sample_Y_pre, test_dataset.output_len,
                            file_name + ' all_sample_gather_gate')
        print('gather图绘制完成！')
    print(f'Accuracy: %.2f %%' % (100 * correct / total))




