from torch.utils.data import DataLoader
from dataset_process.dataset_process import MyDataset
import torch.optim as optim
from time import time
from tqdm import tqdm
import os
from module.pct_ml_zd import TFN2
# from module.pct_ml_zd_1_max import TFN2
# from module.pct_ml_zd_2_ave import TFN2
# from module.pct_ml_zd_3_mplusa import TFN2
# from module.pct_ml_zd_4_base import TFN2
from module.loss import Myloss
from module.loss import Myloss1
from module.loss import Myloss2
from utils.random_seed import setup_seed
from utils.visualization import result_visualization
import torch
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score, roc_auc_score, recall_score, precision_score

setup_seed(30)  # 设置随机数种子
reslut_figure_path = 'result_figure'  # 结果图像保存路径

def test_test(net,dataloader,correct_on_test,flag='test_set'):
    correct = 0
    total = 0
    with torch.no_grad():
        ### No-grad is one of several mechanisms that can enable or disable gradients locally see Locally disabling gradient computation for more information on how they compare.
        net.eval()
        ### 不启用batchnormalization和dropout
        ii = 0
        yy = []
        yy_pre = []
        y_on_test = []
        y_pre_on_test = []
        for x, y in dataloader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            ### 这段代码的意思就是将所有最开始读取数据时的tensor变量copy一份到device指定的GPU上去
            y_pre, _, _, _, _, _, _ = net(x, 'test')
            _, label_index = torch.max(y_pre.data, dim=-1)
            total += label_index.shape[0]
            correct += (label_index == y.long()).sum().item()
            ii += 1
            yyy = y.long().cpu().numpy()
            yyy_pre = label_index.cpu().numpy()
            yy = np.hstack((yy, yyy))
            yy_pre = np.hstack((yy_pre, yyy_pre))

        if flag == 'test_set':
            correct_on_test.append(round((100 * correct / total), 2))
            y_on_test = yy  # ml
            y_pre_on_test = yy_pre  # ml
        print(f'Accuracy on {flag}: %.2f %%' % (100 * correct / total))
        return round((100 * correct / total), 2), correct_on_test, y_on_test, y_pre_on_test

def test_train(net,dataloader,correct_on_train,flag='train_set'):
    correct = 0
    total = 0
    with torch.no_grad():
        ### No-grad is one of several mechanisms that can enable or disable gradients locally see Locally disabling gradient computation for more information on how they compare.
        net.eval()
        ### 不启用batchnormalization和dropout
        ii = 0
        yy = []
        yy_pre = []
        y_on_train = []
        y_pre_on_train = []  #
        for x, y in dataloader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            ### 这段代码的意思就是将所有最开始读取数据时的tensor变量copy一份到device指定的GPU上去
            y_pre, _, _, _, _, _, _ = net(x, 'test')
            _, label_index = torch.max(y_pre.data, dim=-1)
            total += label_index.shape[0]
            correct += (label_index == y.long()).sum().item()
            ii += 1  # ml
            yyy = y.long().cpu().numpy()  # ml
            yyy_pre = label_index.cpu().numpy()  # ml
            yy = np.hstack((yy, yyy))  # ml
            yy_pre = np.hstack((yy_pre, yyy_pre))  # ml
        if flag == 'train_set':
            correct_on_train.append(round((100 * correct / total), 2))
            # y_on_train.append(yy)  # ml
            # y_pre_on_train.append(yy_pre)  # ml
            y_on_train = yy  # ml
            y_pre_on_train = yy_pre  # ml
        print(f'Accuracy on {flag}: %.2f %%' % (100 * correct / total))
        return round((100 * correct / total), 2), correct_on_train, y_on_train, y_pre_on_train


def fold_train(test_interval, draw_key, file_name, EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N, d_fusion, post_fusion_dim,DEVICE,dropout, pe, mask, optimizer_name, path,losstype):
    train_dataset = MyDataset(path, 'train')
    test_dataset = MyDataset(path, 'test')
    train_dataloader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_dataloader = DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    DATA_LEN = train_dataset.train_len  # 训练集样本数量
    d_input = train_dataset.input_len  # 时间部数量
    d_channel = train_dataset.channel_len  # 时间序列维度
    d_output = train_dataset.output_len  # 分类类别
    # 维度展示
    print('data structure: [lines, timesteps, features]')
    print(f'train data size: [{DATA_LEN, d_input, d_channel}]')
    print(f'mytest data size: [{train_dataset.test_len, d_input, d_channel}]')
    print(f'Number of classes: {d_output}')
    net = TFN2(d_model=d_model, d_input=d_input, d_channel=d_channel, d_output=d_output,
              d_hidden=d_hidden,
              q=q, v=v, h=h, N=N, d_fusion=d_fusion, post_fusion_dim=post_fusion_dim, dropout=dropout, pe=pe,
              mask=mask, device=DEVICE).to(DEVICE)
    # 创建loss函数 此处使用 交叉熵损失
    if losstype == 0:
        loss_function = Myloss()
    elif losstype == 1:
        loss_function = Myloss1()
    elif losstype == 2:
        loss_function = Myloss2()
    if optimizer_name == 'Adagrad':
        optimizer = optim.Adagrad(net.parameters(), lr=LR)
    elif optimizer_name == 'Adam':
        optimizer = optim.Adam(net.parameters(), lr=LR)
    history = {'train_acc': [], 'test_acc': [], 'train_acc_person': [], 'test_acc_person': [],'acc': [],'test_precision': [], 'test_recall': [], 'test_f1': []}  # ml
    correct_on_train = []
    correct_on_test = []
    y_on_test_all = []  # ml
    y_pre_on_test_all = []  # ml
    loss_list = []
    time_cost = 0
    net.train()
    max_accuracy = 0
    pbar = tqdm(total=EPOCH)
    ###   tqdm是 Python 进度条库
    begin = time()
    ### time()：获取当前时间戳
    for index in range(EPOCH):
        for i, (x, y) in enumerate(train_dataloader):
            optimizer.zero_grad()
            y_pre, _, _, _, _, _, _ = net(x.to(DEVICE), 'train')
            loss = loss_function(y_pre, y.to(DEVICE))
            loss_list.append(loss.item())
            loss.backward()
            optimizer.step()
        if ((index + 1) % test_interval) == 0:
            current_accuracy,correct_on_test, y_on_test, y_pre_on_test = test_test(net, test_dataloader, correct_on_test, flag = 'test_set')
            ### current_accuracy = test(test_dataloader, 'test_set')
            _, correct_on_train, y_on_train, y_pre_on_train = test_train(net,train_dataloader, correct_on_train,flag ='train_set')
            print(f'当前最大准确率\t测试集:{max(correct_on_test)}%\t 训练集:{max(correct_on_train)}%')
            if current_accuracy > max_accuracy:
                max_accuracy = current_accuracy
                torch.save(net, f'saved_model/{file_name} batch={BATCH_SIZE}_pe={pe}_[{LR},{dropout},{EPOCH},{BATCH_SIZE},{d_model},{d_hidden},{q},{v},{h},{N},{d_fusion},{post_fusion_dim}].pkl')
                y_on_test_all = y_on_test  # ml
                y_pre_on_test_all = y_pre_on_test  # ml
        pbar.update()
        print(f'\n')
    test_precision, test_recall, test_f1, _ = precision_recall_fscore_support(y_on_test_all, y_pre_on_test_all,
                                                                              labels=[1, 0], average=None)#####################################################################################
    acc = accuracy_score(y_on_test_all, y_pre_on_test_all, normalize=True, sample_weight=None)
    print("the result of sklearn package")
    print("y_on_test_all:", y_on_test_all)
    print("sy_pre_on_test_all:", y_pre_on_test_all)
    accuracy = accuracy_score(y_on_test_all, y_pre_on_test_all)
    print("sklearn accuracy:", accuracy)
    print('acc', acc)
    os.rename(f'saved_model/{file_name} batch={BATCH_SIZE}_pe={pe}_[{LR},{dropout},{EPOCH},{BATCH_SIZE},{d_model},{d_hidden},{q},{v},{h},{N},{d_fusion},{post_fusion_dim}].pkl',
              f'saved_model/{file_name} {max_accuracy}_losstype={losstype}_optname={optimizer_name}_pe={pe}_mask={mask}_[{LR},{dropout},{EPOCH},{BATCH_SIZE},{d_model},{d_hidden},{q},{v},{h},{N},{d_fusion},{post_fusion_dim}].pkl')
    end = time()
    time_cost = round((end - begin) / 60, 2)
    # # 结果图
    result_visualization(loss_list=loss_list, correct_on_test=correct_on_test, correct_on_train=correct_on_train,
                         test_interval=test_interval,
                         d_model=d_model, q=q, v=v, h=h, N=N, dropout=dropout, DATA_LEN=DATA_LEN,
                         BATCH_SIZE=BATCH_SIZE,
                         time_cost=time_cost, EPOCH=EPOCH, draw_key=draw_key, reslut_figure_path=reslut_figure_path,
                         file_name=file_name,
                         optimizer_name=optimizer_name, LR=LR, pe=pe, mask=mask)
    correct_on_train_max = max(correct_on_train) # ml
    correct_on_test_max = max(correct_on_test)
    history['train_acc'] = correct_on_train_max  # ml
    history['test_acc'] = correct_on_test_max  # ml
    history['test_precision'] = test_precision
    history['test_recall'] = test_recall
    history['test_f1'] = test_f1
    history['acc'] = acc  # ml
    return history


def fold5_perf(k,path0,test_interval, draw_key, EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N, d_fusion, post_fusion_dim,DEVICE,dropout, pe, mask, optimizer_name, path_indice,loss_type):
    foldperf = {}
    for f in range(0, k):
        # 数据集路径选择
        # path = 'E:\PyCharmWorkSpace\dataset\\MTS_dataset\\pkzd2\\pindices4pdzd_newlr_withoutpooling_xuanzhuanrand_fold5std0_%s.mat' % (
        #     f)
        path2 = '_%s.mat' % (f)
        path = path0 + path2
        ###
        file_name = path.split('\\')[-1][0:path.split('\\')[-1].index('.')]  # 获得文件名字
        setup_seed(30)
        history1 = fold_train(test_interval, draw_key, file_name, EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N,
                              d_fusion,
                              post_fusion_dim, DEVICE, dropout, pe, mask, optimizer_name, path,loss_type)
        foldperf['fold{}'.format(f + 1)] = history1
    return foldperf

def ford_mean(k,foldperf):
    testl_f, tl_f, testa_f, ta_f, acc_l,test_precision_l,test_recall_l, test_f1_l= [], [], [], [], [], [], [], [] # ml
    # testa_f, ta_f = [], []         # ml
    for ff in range(1, k + 1):       # ml                                ####################################################
    # for ff in [5]:
        ta_f.append(foldperf['fold{}'.format(ff)]['train_acc'])  # ml
        testa_f.append(foldperf['fold{}'.format(ff)]['test_acc'])  # ml
        acc_l.append(foldperf['fold{}'.format(ff)]['acc'])  # ml
        test_precision_l.append(foldperf['fold{}'.format(ff)]['test_precision'])  # ml
        test_recall_l.append(foldperf['fold{}'.format(ff)]['test_recall'])  # ml
        test_f1_l.append(foldperf['fold{}'.format(ff)]['test_f1'])  # ml
    print('Performance of {} fold cross validation'.format(k))  # ml
    print("Average Training Acc: {:.5f} \t Average Test Acc: {:.2f}".format(np.mean(ta_f), np.mean(testa_f)))  # ml
    # print("Average Training Acc at the subject level: {:.2f} \t Average Test Acc at the subject level: {:.2f}".format(np.mean(tl_f),np.mean(testl_f))) #ml
    print("Average acc: {:.5f}\t".format(np.mean(acc_l)))  # ml
    print("Average test_precision: {}\t".format(np.mean(test_precision_l,axis=0)))
    print("Average test_recall: {}\t".format(np.mean(test_recall_l,axis=0)))
    print("Average test_f1: {}\t".format(np.mean(test_f1_l,axis=0)))
    list_mean = [np.mean(ta_f), np.mean(testa_f), np.mean(test_precision_l,axis=0), np.mean(test_recall_l,axis=0), np.mean(test_f1_l,axis=0)]

    return list_mean, np.mean(acc_l)

if __name__ == '__main__':
    test_interval = 10  # 测试间隔 单位：epoch
    draw_key = 1  # 大于等于draw_key才会保存图像
    EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N, d_fusion, post_fusion_dim, dropout = 200, 10, 1e-4, 128, 5, 0, 0, 0, 0, 128, 128, 0.2   #001
    DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 选择设备 CPU or GPU
    print(f'use device: {DEVICE}')
    pe = True  # # 设置的是 score=pe score=channel默认没有pe
    mask = True  # 设置的是 score=input的mask score=channel默认没有mask
    loss_type = 0  #0:CrossEntropyLoss() 1:BCELoss() 2:BCEWithLogitsLoss()
    optimizer_name_type = 0
    # pe = False  # # 设置的是双塔中 score=pe score=channel默认没有pe
    # mask = False  # 设置的是双塔中 score=input的mask score=channel默认没有mask
    # 优化器选择
    if optimizer_name_type == 0:
        optimizer_name = 'Adagrad'  ###0
    else:
        optimizer_name = 'Adam'  ###0
    ##5折验证
    k = 5
    path1 = 'Footprint_with_label_fold'
    path2 = 'E:\PyCharmWorkSpace\dataset\\MTS_dataset\\zd\\'
    path = path2 + path1
    for path_indice in range(210, 23):
    # for path_indice in [0]:
        foldperf = fold5_perf(k, path, test_interval, draw_key, EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N,
                              d_fusion, post_fusion_dim, DEVICE, dropout, pe, mask, optimizer_name, path_indice, loss_type)
        path_foldperf = 'dictionary_ml\\' + path1 + f'_foldperf_losstype={loss_type}_optname={optimizer_name}_[{LR},{dropout},{EPOCH},{BATCH_SIZE},{d_model},{d_hidden},{q},{v},{h},{N},{d_fusion},{post_fusion_dim}].npy'
        np.save(path_foldperf, foldperf, allow_pickle=True)
        list_mean, Average_acc = ford_mean(k, foldperf)
        path_ford_mean = 'dictionary_ml\\' + path1 + f'_path_ford_mean_{Average_acc}_losstype={loss_type}_optname={optimizer_name}_[{LR},{dropout},{EPOCH},{BATCH_SIZE},{d_model},{d_hidden},{q},{v},{h},{N},{d_fusion},{post_fusion_dim}].npy'
        np.save(path_ford_mean, list_mean)




























