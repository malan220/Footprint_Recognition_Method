import torch
print('当前使用的pytorch版本：', torch.__version__)
from torch.utils.data import DataLoader
from dataset_process.dataset_process import MyDataset
from utils.TSNE import gather_all_by_tsne2
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from utils.random_seed import setup_seed
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score, roc_auc_score, recall_score, precision_score
import numpy as np
def run_with_savedmodel(save_model_path, data_path):
    path = data_path
    BATCH_SIZE = 100  # 使用的模型的batch_size
    # mts_or_not = True
    # # 加载模型
    net = torch.load(save_model_path,
                     map_location=torch.device('cpu'))  # map_location 设置使用的设备，可能是因为原来的pkl是在colab上用GPU跑的
    # 加载测试集数据
    test_dataset = MyDataset(path, 'test')
    # train_dataset = MyDataset(path, 'train')
    test_dataloader = DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    # train_dataloader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=False)
    correct = 0
    total = 0
    history = {'train_acc': [], 'test_acc': [], 'train_acc_person': [], 'test_acc_person': [],'acc': [],'test_precision': [], 'test_recall': [], 'test_f1': []}  # ml
    with torch.no_grad():
        all_sample_Y = []
        all_sample_Y_pre = []
        for x, y in test_dataloader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            y_pre, encoding, score_input, score_channel, gather_input, gather_channel, gate = net(x.to(DEVICE), 'test')
            _, label_index = torch.max(y_pre.data, dim=-1)
            yyy_pre = label_index
            yyy_pre = yyy_pre.to(DEVICE)
            all_sample_Y_pre.append(yyy_pre)
            all_sample_Y.append(y.long())###########
            total += label_index.shape[0]
            correct += (label_index == y.long()).sum().item()
        all_sample_Y = torch.cat(all_sample_Y, dim=0).numpy()
        all_sample_Y_pre = torch.cat(all_sample_Y_pre, dim=0).numpy()
        print(f'Accuracy: %.2f %%' % (100 * correct / total))
        y_on_test_all = all_sample_Y
        y_pre_on_test_all = all_sample_Y_pre
        test_precision, test_recall, test_f1, _ = precision_recall_fscore_support(y_on_test_all, y_pre_on_test_all,
                                                                                  labels=[1, 0],
                                                                                  average=None)
        # #####################################################################################
        # test_precision, test_recall, test_f1, _ = precision_recall_fscore_support(y_pre_on_test_all, y_pre_on_test_all,
        #                                                                           labels=[1, 0],
        #                                                                           average=None)
        acc = accuracy_score(y_on_test_all, y_pre_on_test_all, normalize=True, sample_weight=None)
        print("the result of sklearn package")
        print("y_on_test_all:", y_on_test_all)
        print("sy_pre_on_test_all:", y_pre_on_test_all)
        auc = roc_auc_score(y_on_test_all, y_pre_on_test_all)
        print("sklearn auc:", auc)
        accuracy = accuracy_score(y_on_test_all, y_pre_on_test_all)
        print("sklearn accuracy:", accuracy)
        recal = recall_score(y_on_test_all, y_pre_on_test_all)
        print("sklearn recall:", recal)
        precision = precision_score(y_on_test_all, y_pre_on_test_all)
        print("sklearn precision:", precision)
        print("sklearn F1-score:{}".format((2 * recal * precision) / (recal + precision)))
        history['train_acc'] = 0  # ml
        history['test_acc'] = acc  # ml
        history['test_precision'] = test_precision
        history['test_recall'] = test_recall
        history['test_f1'] = test_f1
        history['acc'] = acc  # ml
    return history

def fold5_perf(k, path_fold):
    foldperf = {}
    # for f in range(1, k):
    for f in range(0, k):  ###############################
        setup_seed(30)
        save_model_path = 'saved_model3'+'\\' + path_fold + '_fold%s.pkl'% (f)
        data_path = 'mts_data'+'\\'+'pkskstd_78'+'_fold%s.mat'% (f)
        # file_name = save_model_path.split('\\')[-1][0:path.split('\\')[-1].index('.')]  # 获得文件名字
        history1 = run_with_savedmodel(save_model_path, data_path)
        foldperf['fold{}'.format(f + 1)] = history1  # ml
    return foldperf

def ford_mean(k, foldperf):
    testl_f, tl_f, testa_f, ta_f, acc_l,test_precision_l,test_recall_l, test_f1_l= [], [], [], [], [], [], [], [] # ml
    # testa_f, ta_f = [], []         # ml
    for ff in range(1, k + 1):       # ml                                ####################################################
    # for ff in [5]:
        # tl_f.append(np.mean(foldperf['fold{}'.format(ff)]['train_loss'])) #ml
        # testl_f.append(np.mean(foldperf['fold{}'.format(ff)]['test_loss'])) #ml
        # tl_f.append(np.mean(foldperf['fold{}'.format(ff)]['train_acc_person']))  # ml
        # testl_f.append(np.mean(foldperf['fold{}'.format(ff)]['test_acc_person']))  # ml

        ta_f.append(foldperf['fold{}'.format(ff)]['train_acc'])  # ml
        testa_f.append(foldperf['fold{}'.format(ff)]['test_acc'])  # ml
        acc_l.append(foldperf['fold{}'.format(ff)]['acc'])  # ml
        test_precision_l.append(foldperf['fold{}'.format(ff)]['test_precision'])  # ml
        test_recall_l.append(foldperf['fold{}'.format(ff)]['test_recall'])  # ml
        test_f1_l.append(foldperf['fold{}'.format(ff)]['test_f1'])  # ml
    print('Performance of {} fold cross validation'.format(k))  # ml
    print("Average Training Acc: {:.5f} \t Average Test Acc: {:.2f}".format(np.mean(ta_f), np.mean(testa_f)))  # ml
    # print("Average Training Acc at the subject level: {:.2f} \t Average Test Acc at the subject level: {:.2f}".format(np.mean(tl_f),np.mean(testl_f))) #ml
    print("Average acc: {:.5f}\t".format(np.mean(acc_l)))  # ml
    print("Average test_precision: {}\t".format(np.mean(test_precision_l,axis=0)))
    print("Average test_recall: {}\t".format(np.mean(test_recall_l,axis=0)))
    print("Average test_f1: {}\t".format(np.mean(test_f1_l,axis=0)))
    list_mean = [np.mean(ta_f), np.mean(testa_f), np.mean(test_precision_l,axis=0), np.mean(test_recall_l,axis=0), np.mean(test_f1_l,axis=0)]
    return list_mean

if __name__ == '__main__':
    setup_seed(30)
    # DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    DEVICE = torch.device("cpu")
    k = 5
    path_fold = 'pkskstd_78'
    # save_model_path = 'saved_model/ECG4 82.0 batch=100.pkl'
    foldperf = fold5_perf(k, path_fold)
    path_foldperf = f'dictionary_ml\\{path_fold}_foldperf.npy'
    np.save(path_foldperf, foldperf, allow_pickle=True)
    list_mean = ford_mean(k, foldperf)
    # path_ford_mean = 'dictionary_ml\\pkskstd_78_fold_1_%s_path_ford_mean.npy' % (path_indice)
    path_ford_mean = f'dictionary_ml\\{path_fold}_path_ford_mean.npy'
    np.save(path_ford_mean, list_mean)
    print("end")




