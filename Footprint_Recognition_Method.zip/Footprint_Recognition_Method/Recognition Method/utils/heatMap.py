import numpy as np
from dtw import dtw
import matplotlib.pyplot as plt
import seaborn as sns
import os
import argparse
import sys
import torch
from PIL import Image
from torchvision import transforms
import numpy as np
import cv2
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

def heatMap_all(score_input: torch.Tensor,  # 二维数据
                score_channel: torch.Tensor,  # 二维数据
                x: torch.Tensor,  # 二维数据
                save_root: str,
                file_name: str,
                accuracy: str,
                index: int) -> None:
    score_channel = score_channel.detach().numpy()   #tensor.detach().numpy()的含义是将张量分离并转换为NumPy数组。
    score_input = score_input.detach().numpy()
    draw_data = x.detach().numpy()

    euclidean_norm = lambda x, y: np.abs(x - y)  # 用于计算DTW使用的函数,此处是一个计算欧氏距离的函数

    matrix_00 = np.ones((draw_data.shape[1], draw_data.shape[1]))  # 用于记录channel之间DTW值的矩阵
    # matrix_01 = np.ones((draw_data.shape[1], draw_data.shape[1]))  # 用于记录channel之间相差度的矩阵

    # matrix_10 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间DTW值的矩阵
    matrix_11 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间相差度值的矩阵

    for i in range(draw_data.shape[0]):
        for j in range(draw_data.shape[0]):
            x = draw_data[i, :]
            y = draw_data[j, :]
            # d, cost_matrix, acc_cost_matrix, path = dtw(x, y, dist=euclidean_norm)
            # matrix_10[i, j] = d
            matrix_11[i, j] = np.sqrt(np.sum((x - y) ** 2))

    draw_data = draw_data.transpose(-1, -2)
    for i in range(draw_data.shape[0]):
        for j in range(draw_data.shape[0]):
            x = draw_data[i, :]
            y = draw_data[j, :]
            d, cost_matrix, acc_cost_matrix, path = dtw(x, y, dist=euclidean_norm)
            matrix_00[i, j] = d
            # matrix_01[i, j] = np.mean((x - y) ** 2)

    plt.rcParams['figure.figsize'] = (10.0, 8.0)  # 设置figure_size尺寸
    plt.subplot(221)
    sns.heatmap(score_channel, cmap="YlGnBu", vmin=0)
    # plt.title('channel-wise attention')

    plt.subplot(222)
    sns.heatmap(matrix_00, cmap="YlGnBu", vmin=0)
    # plt.title('channel-wise DTW')

    plt.subplot(223)
    sns.heatmap(score_input, cmap="YlGnBu", vmin=0)
    # plt.title('step-wise attention')

    plt.subplot(224)
    sns.heatmap(matrix_11, cmap="YlGnBu", vmin=0)
    # plt.title('step-wise L2 distance')

    # plt.suptitle(f'{file_name.lower()}')

    if os.path.exists(f'{save_root}/{file_name}') == False:
        os.makedirs(f'{save_root}/{file_name}')
    plt.savefig(f'{save_root}/{file_name}/{file_name} accuracy={accuracy} {index}.jpg', dpi=400)

    # plt.show()
    plt.close()

def heatMap_all_half(score_input: torch.Tensor,  # 二维数据
                score_channel: torch.Tensor,  # 二维数据
                x: torch.Tensor,  # 二维数据
                save_root: str,
                file_name: str,
                accuracy: str,
                index: int) -> None:
    score_channel = score_channel.detach().numpy()   #tensor.detach().numpy()的含义是将张量分离并转换为NumPy数组。
    score_input = score_input.detach().numpy()
    draw_data = x.detach().numpy()

    euclidean_norm = lambda x, y: np.abs(x - y)  # 用于计算DTW使用的函数,此处是一个计算欧氏距离的函数

    matrix_00 = np.ones((draw_data.shape[1], draw_data.shape[1]))  # 用于记录channel之间DTW值的矩阵
    # matrix_01 = np.ones((draw_data.shape[1], draw_data.shape[1]))  # 用于记录channel之间相差度的矩阵

    # matrix_10 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间DTW值的矩阵
    matrix_11 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间相差度值的矩阵

    for i in range(draw_data.shape[0]):
        for j in range(draw_data.shape[0]):
            x = draw_data[i, :]
            y = draw_data[j, :]
            # d, cost_matrix, acc_cost_matrix, path = dtw(x, y, dist=euclidean_norm)
            # matrix_10[i, j] = d
            matrix_11[i, j] = np.sqrt(np.sum((x - y) ** 2))

    draw_data = draw_data.transpose(-1, -2)
    for i in range(draw_data.shape[0]):
        for j in range(draw_data.shape[0]):
            x = draw_data[i, :]
            y = draw_data[j, :]
            d, cost_matrix, acc_cost_matrix, path = dtw(x, y, dist=euclidean_norm)
            matrix_00[i, j] = d
            # matrix_01[i, j] = np.mean((x - y) ** 2)

    # plt.rcParams['figure.figsize'] = (10.0, 8.0)  # 设置figure_size尺寸
    plt.rcParams['figure.figsize'] = (10.0, 4.0)  # 设置figure_size尺寸
    # plt.subplot(121)
    # sns.heatmap(score_channel, cmap="YlGnBu", vmin=0)
    # # plt.title('channel-wise attention')
    #
    # plt.subplot(122)
    # sns.heatmap(matrix_00, cmap="YlGnBu", vmin=0)
    # # plt.title('channel-wise DTW')

    plt.subplot(121)
    sns.heatmap(score_input, cmap="YlGnBu", vmin=0)
    # plt.title('step-wise attention')

    plt.subplot(122)
    sns.heatmap(matrix_11, cmap="YlGnBu", vmin=0)
    # plt.title('step-wise L2 distance')

    # plt.suptitle(f'{file_name.lower()}')

    if os.path.exists(f'{save_root}/{file_name}') == False:
        os.makedirs(f'{save_root}/{file_name}')
    plt.savefig(f'{save_root}/{file_name}/{file_name} accuracy={accuracy} {index}_half2.jpg', dpi=400)

    # plt.show()
    plt.close()

def heatMap_all2(score_input: torch.Tensor,  # 二维数据
                score_channel: torch.Tensor,  # 二维数据
                x: torch.Tensor,  # 二维数据
                save_root: str,
                file_name: str,
                accuracy: str,
                index: int) -> None:
    score_channel = score_channel.detach().numpy()   #tensor.detach().numpy()的含义是将张量分离并转换为NumPy数组。
    score_input = score_input.detach().numpy()
    draw_data = x.detach().numpy()

    euclidean_norm = lambda x, y: np.abs(x - y)  # 用于计算DTW使用的函数,此处是一个计算欧氏距离的函数

    # matrix_00 = np.ones((draw_data.shape[1], draw_data.shape[1]))  # 用于记录channel之间DTW值的矩阵
    matrix_01 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录channel之间相差度的矩阵

    # matrix_10 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间DTW值的矩阵
    matrix_11 = np.ones((draw_data.shape[0], draw_data.shape[0]))  # 用于记录input之间相差度值的矩阵

    for i in range(draw_data.shape[0]):
        for j in range(draw_data.shape[0]):
            x = draw_data[i, :]
            y = draw_data[j, :]
            # d, cost_matrix, acc_cost_matrix, path = dtw(x, y, dist=euclidean_norm)
            # matrix_10[i, j] = d
            matrix_11[i, j] = np.sqrt(np.sum((x - y) ** 2))



    # plt.rcParams['figure.figsize'] = (10.0, 8.0)  # 设置figure_size尺寸
    plt.rcParams['figure.figsize'] = (5.0, 13.5)  # 设置figure_size尺寸

    plt.subplot(311)
    # sns.heatmap(score_input, cmap="YlGnBu", vmin=0)
    sns.heatmap(score_input, cmap="YlGnBu", robust=True)
    plt.title('Maximum pooling module attention',x=0.5,y=-0.2)

    plt.subplot(312)
    # sns.heatmap(score_channel, cmap="YlGnBu", vmin=0)
    sns.heatmap(score_channel, cmap="YlGnBu", robust=True)
    plt.title('Average pooling module attention',x=0.5,y=-0.2)


    plt.subplot(313)
    # sns.heatmap(matrix_11, cmap="YlGnBu", vmin=0)
    sns.heatmap(matrix_11, cmap="YlGnBu", robust=True)
    plt.title('L2 distance',x=0.5,y=-0.2)

    # plt.suptitle(f'{file_name.lower()}')

    if os.path.exists(f'{save_root}/{file_name}') == False:
        os.makedirs(f'{save_root}/{file_name}')
    # plt.savefig(f'{save_root}/{file_name}/{file_name} {index}.jpg', dpi=400)
    plt.savefig(f'{save_root}/{file_name}/{file_name} accuracy={accuracy} {index}.jpg', dpi=1000)

    # plt.show()
    plt.close()
def show_mask_on_image(matrix1, mask):
    img = matrix1
    matrix20 = cv2.resize(np.array(mask), (img.shape[1], img.shape[0]))
    np_img = np.array(img)
    img = np.float32(np_img) * 255 / np.max(np_img)
    img30 = np.float32(matrix20) * 255 / np.max(matrix20)
    img2 = cv2.applyColorMap(np.uint8(img), cv2.COLORMAP_BONE)
    img3 = cv2.applyColorMap(np.uint8(img30), cv2.COLORMAP_JET)
    cam = img3 + np.float32(img2)
    cam = cam / np.max(cam)
    cam = np.uint8(255 * cam)
    return img2,img3,cam

# if __name__ == '__main__':
#     matrix = torch.Tensor(range(24)).reshape(2, 3, 4)
#     print(matrix.shape)
#     file_name = 'lall'
#     epcoh = 1
#
#     data_channel = matrix.detach()
#     data_input = matrix.detach()
#     A = data_channel[0].data.cpu().numpy()
#
#     plt.subplot(2, 2, 1)
#     sns.heatmap(data_channel[0].data.cpu().numpy())
#     plt.title("1")
#
#     plt.subplot(2, 2, 2)
#     sns.heatmap(data_input[0].data.cpu().numpy())
#     plt.title("2")
#
#     plt.subplot(2, 2, 3)
#     sns.heatmap(data_input[0].data.cpu().numpy())
#     plt.title("3")
#
#     plt.subplot(2, 2, 4)
#     sns.heatmap(data_input[0].data.cpu().numpy(), cmap="YlGnBu")
#     plt.title("4")
#
#     plt.suptitle("JapaneseVowels Attention Heat Map", fontsize='x-large', fontweight='bold')
#     # plt.savefig('result_figure/JapaneseVowels Attention Heat Map.png')
#     plt.savefig('gather_figure/JapaneseVowels Attention Heat Map.png')
#     plt.show()

if __name__ == '__main__':
    matrix1 = torch.Tensor(range(24)).reshape(4, 6)
    matrix2 = torch.Tensor(range(16)).reshape(4, 4)
    print(matrix1.shape)
    file_name = 'lall'
    epcoh = 1

    data_channel = matrix1.detach()
    data_input = matrix2.detach()
    A = data_channel.data.cpu().numpy()
    B = data_input.data.cpu().numpy()

    plt.subplot(2, 2, 1)
    sns.heatmap(data_channel.data.cpu().numpy())
    plt.title("1")

    plt.subplot(2, 2, 2)
    sns.heatmap(data_input.data.cpu().numpy())
    plt.title("2")

    plt.subplot(2, 2, 3)
    sns.heatmap(data_input.data.cpu().numpy())
    plt.title("3")

    plt.subplot(2, 2, 4)
    sns.heatmap(data_input.data.cpu().numpy(), cmap="YlGnBu")
    plt.title("4")

    plt.suptitle("JapaneseVowels Attention Heat Map", fontsize='x-large', fontweight='bold')
    # plt.savefig('result_figure/JapaneseVowels Attention Heat Map.png')
    plt.savefig('gather_figure/JapaneseVowels Attention Heat Map.png')
    plt.show()



    [image1, mask1, mask_on_image1]= show_mask_on_image(matrix1, matrix2)
    # img = cv2.imread(args.image_path)
    # name = "grad_rollout123.png"
    cv2.imwrite("input2.png", image1)
    cv2.imwrite("input3.png", mask1)
    cv2.imwrite("input4.png", mask_on_image1)
    cv2.waitKey(-1)
