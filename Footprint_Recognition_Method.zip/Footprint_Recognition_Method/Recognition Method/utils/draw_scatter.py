###画足底压力散点图
import matplotlib.pyplot as plt
import numpy as np

# 下载和导入需要的库


import os
import pandas as pd
# Creating random dataset



def draw_scatter(sample,file_name,index):
    #获取三维足底数据
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    fig = plt.figure(figsize=(16, 12))
    ax = plt.axes(projection="3d")
    ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Add x, and y gridlines for the figure
    # ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Creating the color map for the plot
    my_cmap = plt.get_cmap('jet')
    # Creating the 3D plot
    sctt = ax.scatter3D(channel_0, channel_1, channel_2, alpha=0.8, c=channel_2, cmap=my_cmap)  # , marker='^'

    # plt.title("3D scatter plot in Python")
    ax.set_xlabel('X-axis', fontweight='bold')
    ax.set_ylabel('Y-axis', fontweight='bold')
    ax.set_zlabel('Z-axis', fontweight='bold')
    fig.colorbar(sctt, ax=ax, shrink=0.6, aspect=5)
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_scatter3D{index}.jpg', dpi=1000)
    plt.show()
    plt.close()

def draw_scatter_2d(sample, file_name, index):

    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure(figsize=(12, 6))
    # 绘制前两个特征的二维散点图
    plt.scatter(channel_0, channel_1, c = channel_2, alpha=0.8)
    # plt.title("2D scatter plot in Python")
    plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
    plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
    plt.axis('equal')
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_scatter2D{index}.jpg', dpi=1000)
    plt.show()
    plt.close()




def draw_scatter_2d_score_max(sample, file_name, index, score_input, index_q):
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure(figsize=(6, 12))

    # 绘制前两个特征的二维散点图
    plt.scatter(channel_0, channel_1, c = score_input[index_q], alpha=0.8)

    plt.scatter(channel_0[index_q], channel_1[index_q], s=100, c = "red", marker='x',alpha=1)
    plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)

    # plt.title("2D scatter plot in Python")
    plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
    plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
    plt.axis('equal')
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_max{index}_q{index_q}.jpg', dpi=1000)
    plt.show()
    plt.close()

def draw_scatter_2d_score_avr(sample, file_name, index, score_channel, index_q):
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure(figsize=(6, 12))

    # 绘制前两个特征的二维散点图
    plt.scatter(channel_0, channel_1, c = score_channel[index_q], alpha=0.8)

    plt.scatter(channel_0[index_q], channel_1[index_q], s=100, c = "red", marker='x',alpha=1)

    plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)

    # plt.title("2D scatter plot in Python")
    plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
    plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
    plt.axis('equal')
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_avr{index}_q{index_q}.jpg', dpi=1000)
    plt.show()
    plt.close()




def draw_scatter_3d_score_max(sample, file_name, index, score_input, index_q):
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()


    fig = plt.figure(figsize=(16, 12))
    ax = plt.axes(projection="3d")
    ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Add x, and y gridlines for the figure
    # ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Creating the color map for the plot
    my_cmap = plt.get_cmap('jet')
    # Creating the 3D plot
    sctt = ax.scatter3D(channel_0, channel_1, channel_2, alpha=0.8, c = score_input[index_q], cmap=my_cmap)  # , marker='^'
    sctt = ax.scatter3D(channel_0[index_q], channel_1[index_q],channel_2[index_q], s=100, c = "red", marker='x',alpha=1)  # , marker='^'

    plt.title("3D scatter plot in Python")
    ax.set_xlabel('X-axis', fontweight='bold')
    ax.set_ylabel('Y-axis', fontweight='bold')
    ax.set_zlabel('Z-axis', fontweight='bold')
    # fig.colorbar(sctt, ax=ax, shrink=0.6, aspect=5)
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_3d_score_max{index}_q{index_q}.jpg', dpi=1000)
    plt.show()
    plt.close()
def draw_scatter_3d_score_avr(sample, file_name, index, score_channel, index_q):
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()


    fig = plt.figure(figsize=(16, 12))
    ax = plt.axes(projection="3d")
    ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Add x, and y gridlines for the figure
    # ax.grid(b=True, color='blue', linestyle='-.', linewidth=0.5, alpha=0.3)
    # Creating the color map for the plot
    my_cmap = plt.get_cmap('jet')
    # Creating the 3D plot
    sctt = ax.scatter3D(channel_0, channel_1, channel_2, alpha=0.8, c = score_channel[index_q], cmap=my_cmap)  # , marker='^'
    sctt = ax.scatter3D(channel_0[index_q], channel_1[index_q],channel_2[index_q], s=100, c = "red", marker='x',alpha=1)  # , marker='^'
    plt.title("3D scatter plot in Python")
    ax.set_xlabel('X-axis', fontweight='bold')
    ax.set_ylabel('Y-axis', fontweight='bold')
    ax.set_zlabel('Z-axis', fontweight='bold')
    # fig.colorbar(sctt, ax=ax, shrink=0.6, aspect=5)
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_3d_score_avr{index}_q{index_q}.jpg', dpi=1000)
    plt.show()
    plt.close()



def draw_scatter_2d_score_all(sample, file_name, index, score_input, score_channel,bb):
    ####画出最大模块和平均模块连续的注意力图
    # a = len(bb)
    a0 = 1
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure()
    plt.figure(figsize=(5, 12))
    for index_q in bb:
        # if index_n = int(epoch / 25)
        # print(a0)
        plt.subplot(4, 2, a0)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c=score_input[index_q], s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'max_q_{index_q}')
        ###
        plt.subplot(4, 2, a0+1)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c = score_channel[index_q],s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'ave_q_{index_q}')
        a0 = a0+2
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_max{index}_q{bb}_all.jpg', dpi=1000)
    plt.show()
    plt.close()

def draw_scatter_2d_score_all2(sample, file_name, index, score_input, score_channel,bb):
    ####画出最大模块和平均模块连续的注意力图
    # a = len(bb)
    a0 = 1
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure()
    plt.figure(figsize=(5, 12))
    for index_q in bb:
        # if index_n = int(epoch / 25)
        # print(a0)
        plt.subplot(4, 2, a0)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c=score_input[index_q], s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'max_q_{index_q}')
        ###
        plt.subplot(4, 2, a0+1)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c = score_channel[index_q],s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'ave_q_{index_q}')
        a0 = a0+2
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_max{index}_q{bb}_all.jpg', dpi=1000)
    plt.show()
    plt.close()

def draw_scatter_2d_score_all_max(sample, file_name, index, score_input, score_channel,bb):
    ####画出最大模块连续的注意力图
    # a = len(bb)
    a0 = 1
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure()
    plt.figure(figsize=(5, 10))
    for index_q in bb:
        # if index_n = int(epoch / 25)
        # print(a0)
        plt.subplot(5, 2, a0)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c=score_input[index_q], s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'max_q_{index_q}')
        ###
        a0 = a0+1
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_max{index}_q_all_max.jpg', dpi=1000)
    plt.show()
    plt.close()

def draw_scatter_2d_score_all_ave(sample, file_name, index, score_input, score_channel,bb):
    ####画出最大模块连续的注意力图
    # a = len(bb)
    a0 = 1
    sample = sample.transpose(-1, -2)
    channel_0 = sample[0, :].numpy().tolist()
    channel_1 = sample[1, :].numpy().tolist()
    channel_2 = sample[2, :].numpy().tolist()
    plt.figure()
    plt.figure(figsize=(5, 10))
    for index_q in bb:
        # if index_n = int(epoch / 25)
        # print(a0)
        plt.subplot(5, 2, a0)
        # plt.figure(figsize=(6, 12))
        # 绘制前两个特征的二维散点图
        plt.scatter(channel_0, channel_1, c = score_channel[index_q], s=5, alpha=0.8)
        plt.scatter(channel_0[index_q], channel_1[index_q], s=5, c="red", marker='x', alpha=1)
        plt.text(channel_0[index_q], channel_1[index_q], f'{index_q}', fontsize=12)
        # plt.title("2D scatter plot in Python")
        # plt.xlabel('X-axis', fontweight='bold')  # 横坐标轴标题
        # plt.ylabel('Y-axis', fontweight='bold')  # 纵坐标轴标题
        plt.axis('equal')
        # plt.title(f'max_q_{index_q}')
        ###
        a0 = a0+1
    plt.savefig(f'gather_figure/{file_name.split(" ")[0]}/{file_name}_2d_score_max{index}_q_all_ave.jpg', dpi=1000)
    plt.show()
    plt.close()


if __name__ == '__main__':
    z = 4 * np.tan(np.random.randint(10, size=(500))) + np.random.randint(100, size=(500))
    x = 4 * np.cos(z) + np.random.normal(size=500)
    y = 4 * np.sin(z) + 4 * np.random.normal(size=500)
    print('正在绘制散点图...')
    draw_scatter(sample, file_name + 'sample_scatter', index)
    # draw_heatmap_anylasis3(sample, file_name +' sample_heatmap_anylasis', index)
    print('散点图绘制完成！')
