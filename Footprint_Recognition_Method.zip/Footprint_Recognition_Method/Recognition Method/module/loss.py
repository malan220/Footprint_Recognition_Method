from torch.nn import Module
import torch
from torch.nn import CrossEntropyLoss
from torch.nn import BCELoss
from torch.nn import BCEWithLogitsLoss


class Myloss(Module):
    def __init__(self):
        super(Myloss, self).__init__()
        self.loss_function = CrossEntropyLoss()
        #self.loss_function = BCEWithLogitsLoss()

    def forward(self, y_pre, y_true):
        y_true = y_true.long()
        loss = self.loss_function(y_pre, y_true)

        return loss

# class Myloss(Module):
#     def __init__(self):
#         super(Myloss, self).__init__()
#         self.loss_function = CrossEntropyLoss()
#         # self.loss_function = BCEWithLogitsLoss()
#         # self.loss_function = BCELoss()
#
#
#     def forward(self, y_pre, y_true):
#         y_true = y_true.long()
#         # y_true = torch.FloatTensor(y_true)
#         # y_true = torch.cuda.FloatTensor(y_true)
#         # y_true = y_true.int()
#         # y_true = torch.nn.functional.one_hot(y_true.to(torch.int64)).float()########
#
#         loss = self.loss_function(y_pre, y_true)
#         return loss



class Myloss1(Module):
    def __init__(self):
        super(Myloss1, self).__init__()
        # self.loss_function = CrossEntropyLoss()
        # self.loss_function = BCEWithLogitsLoss()
        self.loss_function = BCELoss()


    def forward(self, y_pre, y_true):
        # y_true = y_true.long()
        # y_true = torch.FloatTensor(y_true)
        y_true = torch.cuda.FloatTensor(y_true)
        y_true = y_true.int()
        y_true = torch.nn.functional.one_hot(y_true.to(torch.int64)).float()########
        loss = self.loss_function(y_pre, y_true)
        return loss


class Myloss2(Module):
    def __init__(self):
        super(Myloss2, self).__init__()
        # self.loss_function = CrossEntropyLoss()
        self.loss_function = BCEWithLogitsLoss()
        # self.loss_function = BCELoss()


    def forward(self, y_pre, y_true):
        # y_true = y_true.long()
        # y_true = torch.FloatTensor(y_true)
        y_true = torch.cuda.FloatTensor(y_true)
        y_true = y_true.int()
        y_true = torch.nn.functional.one_hot(y_true.to(torch.int64)).float()########
        loss = self.loss_function(y_pre, y_true)
        return loss