from torch.autograd import Variable
from numpy import *
import torch
from torch import nn
from torch.nn import Module
import torch.nn.functional as F



class Transformer_baseline(Module):
    '''
    Implements the Tensor Fusion Networks for multimodal sentiment analysis as is described in:
    Zadeh, Amir, et al. "Tensor fusion network for multimodal sentiment analysis." EMNLP 2017 Oral.
    '''
    def __init__(self,
                 d_model: int,
                 d_input: int,
                 d_channel: int,
                 d_output: int,
                 d_hidden: int,
                 q: int,
                 v: int,
                 h: int,
                 N: int,
                 d_fusion: int,
                 post_fusion_dim: int,
                 device: str,
                 # post_fusion_dim:int,
                 dropout: float = 0.1,
                 pe: bool = False,
                 mask: bool = False,
                 output_channels=20):
        super(Transformer_baseline, self).__init__()

        d_model = d_model
        d_hidden = d_hidden
        q = q
        v = v
        h = h
        mask = mask
        dropout = dropout
        device = device
        d_fusion = d_fusion
        post_fusion_dim = post_fusion_dim

        # dimensions are specified in the order of audio, video and tex

       ########################
        self.conv1 = nn.Conv1d(3, 128, kernel_size=1, bias=False)###############################################################
        self.conv2 = nn.Conv1d(128, 128, kernel_size=1, bias=False)

        self.bn1 = nn.BatchNorm1d(128)
        self.bn2 = nn.BatchNorm1d(128)

        self.sa1 = SA_Layer(128)
        self.sa2 = SA_Layer(128)
        self.sa3 = SA_Layer(128)
        self.sa4 = SA_Layer(128)

        self.conv_fuse = nn.Sequential(nn.Conv1d(128, 512, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(512),
                                   nn.LeakyReLU(0.2))


        self.linear1 = nn.Linear(512, 256, bias=False)
        self.bn6 = nn.BatchNorm1d(256)
        self.dp1 = nn.Dropout(p=0.5)
        self.linear2 = nn.Linear(256, 256)
        self.bn7 = nn.BatchNorm1d(256)
        self.dp2 = nn.Dropout(p=0.5)
        self.linear3 = nn.Linear(256, output_channels)

        self.relu = nn.ReLU()
        self.gate = torch.nn.Linear(20, d_fusion)


    def forward(self, x,stage):
        '''
        Args:
            audio_x: tensor of shape (batch_size, audio_in)
            video_x: tensor of shape (batch_size, video_in)
            text_x: tensor of shape (batch_size, sequence_len, text_in)
        '''
        post_fusion_y_1=0
        score_input=0
        score_channel=0
        input_to_gather=0
        channel_to_gather=0
        post_fusion_y_2=0
        stage = stage
        batch_size, _, N = x.shape
        # print("x.shape",x.shape)
        x = self.conv1(x.transpose(-1, -2))
        x = self.bn1(x)
        x = F.relu(x)  # B, D, N
        x = self.conv2(x)
        x = self.bn2(x)
        x = F.relu(x)  # B, D, N
        # x1 = self.sa1(x)
        # x2 = self.sa2(x1)
        # x3 = self.sa3(x2)
        # x4 = self.sa4(x3)
        #
        # x = torch.cat((x1, x2, x3, x4), dim=1)
        # # x = torch.cat((x1, x2), dim=1)
        # # x = x1
        # x = torch.cat((x), dim=1)

        x = self.conv_fuse(x)
        x = F.adaptive_max_pool1d(x, 1).view(batch_size, -1)



        ############# x = torch.max(x, 2)
        ################# x = x.view(batch_size, -1)
        x = F.relu(self.bn6(self.linear1(x)))
        x = self.dp1(x)
        #### x = x.view(batch_size, -1)
        x = F.relu(self.bn7(self.linear2(x)))
        x = self.dp2(x)
        x = self.linear3(x)
        #
        x = x.reshape(x.shape[0], -1)
        x = F.softmax(self.gate(x), dim=-1)
        # return x

        # return x, post_fusion_y_1, score_input
        return x, post_fusion_y_1, score_input, score_channel, input_to_gather, channel_to_gather, post_fusion_y_2

class Transformer3(Module):
    '''
    Implements the Tensor Fusion Networks for multimodal sentiment analysis as is described in:
    Zadeh, Amir, et al. "Tensor fusion network for multimodal sentiment analysis." EMNLP 2017 Oral.
    '''
    def __init__(self,
                 d_model: int,
                 d_input: int,
                 d_channel: int,
                 d_output: int,
                 d_hidden: int,
                 q: int,
                 v: int,
                 h: int,
                 N: int,
                 d_fusion: int,
                 post_fusion_dim: int,
                 device: str,
                 # post_fusion_dim:int,
                 dropout: float = 0.1,
                 pe: bool = False,
                 mask: bool = False,
                 output_channels=20):
        super(Transformer3, self).__init__()

        d_model = d_model
        d_hidden = d_hidden
        q = q
        v = v
        h = h
        mask = mask
        dropout = dropout
        device = device
        d_fusion = d_fusion
        post_fusion_dim = post_fusion_dim

        # dimensions are specified in the order of audio, video and tex

       ########################
        self.conv1 = nn.Conv1d(3, 128, kernel_size=1, bias=False)###############################################################
        self.conv2 = nn.Conv1d(128, 128, kernel_size=1, bias=False)

        self.bn1 = nn.BatchNorm1d(128)
        self.bn2 = nn.BatchNorm1d(128)

        self.sa1 = SA_Layer(128)
        self.sa2 = SA_Layer(128)
        self.sa3 = SA_Layer(128)
        self.sa4 = SA_Layer(128)

        self.conv_fuse = nn.Sequential(nn.Conv1d(128, 512, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(512),
                                   nn.LeakyReLU(0.2))


        # self.linear1 = nn.Linear(21248, 256, bias=False)
        self.linear1 = nn.Linear(72576, 512, bias=False)
        self.bn6 = nn.BatchNorm1d(512)
        self.dp1 = nn.Dropout(p=0.5)
        self.linear2 = nn.Linear(512, 256)
        self.bn7 = nn.BatchNorm1d(256)
        self.dp2 = nn.Dropout(p=0.5)
        self.linear3 = nn.Linear(256, output_channels)

        self.relu = nn.ReLU()
        self.gate = torch.nn.Linear(20, d_fusion)


    def forward(self, x,stage):
        '''
        Args:
            audio_x: tensor of shape (batch_size, audio_in)
            video_x: tensor of shape (batch_size, video_in)
            text_x: tensor of shape (batch_size, sequence_len, text_in)
        '''
        post_fusion_y_1=0
        score_input=0
        score_channel=0
        input_to_gather=0
        channel_to_gather=0
        post_fusion_y_2=0
        stage = stage
        batch_size, _, N = x.shape
        # print("x.shape",x.shape)
        x = self.conv1(x.transpose(-1, -2))
        x = self.bn1(x)
        x = F.relu(x)  # B, D, N
        # x = F.tanh(x)  # B, D, N##########################
        x = self.conv2(x)
        x = self.bn2(x)
        x = F.relu(x)  # B, D, N
        # x = F.tanh(x)  # B, D, N##########################
        # x1 = self.sa1(x)
        # x2 = self.sa2(x1)
        # x3 = self.sa3(x2)
        # x4 = self.sa4(x3)
        #
        # x = torch.cat((x1, x2, x3, x4), dim=1)
        # x = torch.cat((x1, x2), dim=1)
        # x = x1

        # x = self.conv_fuse(x)
        # x = F.adaptive_max_pool1d(x, 1).view(batch_size, -1)
        x = x.view(batch_size, -1)




        ############# x = torch.max(x, 2)
        # ################# x = x.view(batch_size, -1)
        x = F.relu(self.bn6(self.linear1(x)))
        x = self.dp1(x)
        #### x = x.view(batch_size, -1)
        x = F.relu(self.bn7(self.linear2(x)))
        x = self.dp2(x)
        x = self.linear3(x)
        # ##
        # # x = x.reshape(x.shape[0], -1)
        # # x = F.softmax(self.gate(x), dim=-1)
        # # return x

        # return x, post_fusion_y_1, score_input
        return x, post_fusion_y_1, score_input, score_channel, input_to_gather, channel_to_gather, post_fusion_y_2


class Transformer4(Module):
    '''
    Implements the Tensor Fusion Networks for multimodal sentiment analysis as is described in:
    Zadeh, Amir, et al. "Tensor fusion network for multimodal sentiment analysis." EMNLP 2017 Oral.
    '''
    def __init__(self,
                 d_model: int,
                 d_input: int,
                 d_channel: int,
                 d_output: int,
                 d_hidden: int,
                 q: int,
                 v: int,
                 h: int,
                 N: int,
                 d_fusion: int,
                 post_fusion_dim: int,
                 device: str,
                 # post_fusion_dim:int,
                 dropout: float = 0.1,
                 pe: bool = False,
                 mask: bool = False,
                 output_channels=20):
        super(Transformer4, self).__init__()

        d_model = d_model
        d_hidden = d_hidden
        q = q
        v = v
        h = h
        mask = mask
        dropout = dropout
        device = device
        d_fusion = d_fusion
        post_fusion_dim = post_fusion_dim

        # dimensions are specified in the order of audio, video and tex

       ########################
        self.conv1 = nn.Conv1d(3, 128, kernel_size=1, bias=False)
        self.conv2 = nn.Conv1d(128, 128, kernel_size=1, bias=False)

        self.bn1 = nn.BatchNorm1d(128)
        self.bn2 = nn.BatchNorm1d(128)

        self.sa1 = SA_Layer(128)
        self.sa2 = SA_Layer(128)
        self.sa3 = SA_Layer(128)
        self.sa4 = SA_Layer(128)

        self.conv_fuse = nn.Sequential(nn.Conv1d(512, 512, kernel_size=1, bias=False),
                                   nn.BatchNorm1d(512),
                                   nn.LeakyReLU(0.2))


        self.linear1 = nn.Linear(512, 256, bias=False)
        self.bn6 = nn.BatchNorm1d(256)
        self.dp1 = nn.Dropout(p=0.5)

        self.linear2 = nn.Linear(256, 256)
        self.bn7 = nn.BatchNorm1d(256)
        self.dp2 = nn.Dropout(p=0.5)

        self.linear3 = nn.Linear(256, output_channels)

        self.relu = nn.ReLU()
        self.gate = torch.nn.Linear(20, d_fusion)


    def forward(self, x,stage):
        '''
        Args:
            audio_x: tensor of shape (batch_size, audio_in)
            video_x: tensor of shape (batch_size, video_in)
            text_x: tensor of shape (batch_size, sequence_len, text_in)
        '''
        post_fusion_y_1=0
        score_input=0
        score_channel=0
        input_to_gather=0
        channel_to_gather=0
        post_fusion_y_2=0
        stage = stage
        batch_size, _, N = x.shape
        # print("x.shape",x.shape)
        x = self.conv1(x.transpose(-1, -2))
        x = self.bn1(x)
        x = F.relu(x)  # B, D, N
        x = self.conv2(x)
        x = self.bn2(x)
        x = F.relu(x)  # B, D, N
        x1 = self.sa1(x)
        x2 = self.sa2(x1)
        x3 = self.sa3(x2)
        x4 = self.sa4(x3)

        x = torch.cat((x1, x2, x3, x4), dim=1)
        # x = torch.cat((x1, x2), dim=1)
        # x = x1

        x = self.conv_fuse(x)
        # x = F.adaptive_max_pool1d(x, 1).view(batch_size, -1)
        x = F.adaptive_avg_pool1d(x, 1).view(batch_size, -1)



        ############## x = torch.max(x, 2)
        ################### x = x.view(batch_size, -1)
        x = F.relu(self.bn6(self.linear1(x)))
        x = self.dp1(x)
        ##### x = x.view(batch_size, -1)
        x = F.relu(self.bn7(self.linear2(x)))
        x = self.dp2(x)
        # x = self.linear3(x)

        ##
        # x = x.reshape(x.shape[0], -1)
        # x = F.softmax(self.gate(x), dim=-1)
        ##

        # return x, post_fusion_y_1, score_input
        return x, post_fusion_y_1, score_input, score_channel, input_to_gather, channel_to_gather, post_fusion_y_2


class SA_Layer1(nn.Module):
    def __init__(self, channels):
        super(SA_Layer, self).__init__()
        self.q_conv = nn.Conv1d(channels, channels // 4, 1, bias=False)
        self.k_conv = nn.Conv1d(channels, channels // 4, 1, bias=False)
        self.q_conv.weight = self.k_conv.weight
        # self.q_conv.conv.weight = self.k_conv.conv.weight
        self.v_conv = nn.Conv1d(channels, channels, 1)
        self.trans_conv = nn.Conv1d(channels, channels, 1)
        self.after_norm = nn.BatchNorm1d(channels)
        self.act = nn.ReLU()
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        x = x
        x_q = self.q_conv(x).permute(0, 2, 1)  # b, n, c
        x_k = self.k_conv(x)  # b, c, n
        x_v = self.v_conv(x)
        energy = torch.matmul(x_q, x_k)  # b, n, n
        attention = self.softmax(energy)
        attention = attention / (1e-9 + attention.sum(dim=1, keepdims=True))
        x_r = torch.matmul(x_v, attention)  # b, c, n
        x_r = self.act(self.after_norm(self.trans_conv(x - x_r)))
        x = x + x_r
        return x


class SA_Layer(nn.Module):
    def __init__(self, channels):
        super(SA_Layer, self).__init__()
        self.q_conv = nn.Conv1d(channels, channels // 4, 1, bias=False)
        self.k_conv = nn.Conv1d(channels, channels // 4, 1, bias=False)
        # self.q_conv.weight = self.k_conv.weight
        # self.q_conv.conv.weight = self.k_conv.conv.weight
        self.v_conv = nn.Conv1d(channels, channels, 1)
        self.v2_conv = nn.Conv1d(channels, channels, 1)
        self.trans_conv = nn.Conv1d(channels, channels, 1)
        self.after_norm = nn.BatchNorm1d(channels)
        self.act = nn.ReLU()
        self.softmax = nn.Softmax(dim=-1)
        # self.softmax = nn.LogSoftmax(dim=-1)
        # self.gumbelsoftmax = nn.functional.gumbel_softmax()

    def forward(self, x):
        x = x
        x_q = self.q_conv(x).permute(0, 2, 1) # b, n, c
        x_k = self.k_conv(x)# b, c, ns
        x_v = self.v_conv(x)
        x_v = x_v / (1e-9 + x_v.sum(dim=0, keepdims=True))  #################
        x_v2 = self.v2_conv(x)#ml
        # energy = Euclidean_Distance2(x_q, x_k)  # b, n, n
        # energy = Chebyshev_Distance(x_q, x_k)  # b, n, n
        energy = Manhattan_Distance(x_q, x_k)  # b, n, n
        # energy = p_inf_Distance(x_q, x_k)  # b, n, n
        # energy = Cos_Distance(x_q, x_k)  # b, n, n

        # energy = Manhattan_Distance(x_q, x_k) - torch.matmul(x.permute(0, 2, 1), x)  # b, n, n

        # energy = torch.matmul(x_q, x_k) - torch.matmul(x.permute(0, 2, 1), x) # b, n, n
        attention = energy
        attention = self.softmax(attention)
        attention = attention / (1e-9 + attention.sum(dim=0, keepdims=True))  #################
        # attention = F.gumbel_softmax(energy, tau=1, hard=True)#ml
        # attention = energy#ml

        # attention = self.softmax(attention)
        x_r = torch.matmul(x_v, attention) # b, c, n
        # x_r = torch.mul(x_r, x)  #ml
        # x_r = self.act(self.after_norm(self.trans_conv(x_r)))
        x_r = self.act(self.after_norm(self.trans_conv(x - x_r)))
        # x_r = self.act(self.after_norm(self.trans_conv(x_v2-x_r)))#ml
        x = x + x_r
        # x = x_r
        return x, attention

def Manhattan_Distance(mat1, mat2):
    # aa = torch.randint(0, 10, (100, 567, 16))
    # bb = torch.randint(0, 10, (100, 16, 567))
    # mat20 = mat2.permute(0, 2, 1)
    mat10 = torch.unsqueeze(mat1.permute(0, 2, 1), -1)
    mat20 = torch.unsqueeze(mat2, -1)
    aa3 = torch.sub(mat10, mat20.permute(0, 1, 3, 2))
    aa6 = torch.norm(aa3, p=1, dim=1, keepdim=False)
    # aa4 = torch.abs(aa3)
    # value_output = torch.sum(aa4, 1, keepdim=False)
    return aa6

class TFN2(Module):######baseline
    '''
    Implements the Tensor Fusion Networks for multimodal sentiment analysis as is described in:
    Zadeh, Amir, et al. "Tensor fusion network for multimodal sentiment analysis." EMNLP 2017 Oral.
    '''
    def __init__(self,
                 d_model: int,
                 d_input: int,
                 d_channel: int,
                 d_output: int,
                 d_hidden: int,
                 q: int,
                 v: int,
                 h: int,
                 N: int,
                 d_fusion: int,
                 post_fusion_dim: int,
                 device: str,
                 # post_fusion_dim:int,
                 dropout: float = 0.1,
                 pe: bool = False,
                 mask: bool = False):
        super(TFN2, self).__init__()

        d_model = d_model
        d_hidden = d_hidden
        q = q
        v = v
        h = h
        mask = mask
        dropout = dropout
        device = device
        d_fusion = d_fusion
        post_fusion_dim = post_fusion_dim

        # dimensions are specified in the order of audio, video and text
        self.net1 = Transformer3(d_model=d_model, d_input=d_input, d_channel=d_channel, d_output=d_output,
                          d_hidden=d_hidden,q=q, v=v, h=h, N=N, d_fusion = d_fusion, post_fusion_dim = post_fusion_dim, dropout=dropout, pe=pe, mask=mask, device=device).to(device)
        self.net2 = Transformer4(d_model=d_model, d_input=d_input, d_channel=d_channel, d_output=d_output,
                                           d_hidden=d_hidden, q=q, v=v, h=h, N=N, d_fusion = d_fusion, post_fusion_dim = post_fusion_dim, dropout=dropout, pe=pe, mask=mask,
                                           device=device).to(device)
        # self.post_fusion_dim = post_fusion_dim
        self.post_fusion_dim = post_fusion_dim ###########################################################################################################################
        self.post_fusion_dropout = nn.Dropout(dropout)
        # self.post_fusion_layer_1 = nn.Linear((40 + 1) * (40 + 1), self.post_fusion_dim)###################################################################
        self.post_fusion_layer_1 = nn.Linear(21,self.post_fusion_dim)  ###################################################################
        self.post_fusion_layer_2 = nn.Linear(self.post_fusion_dim, self.post_fusion_dim)
        self.post_fusion_layer_3 = nn.Linear(self.post_fusion_dim, d_output)
        # self.output_linear = torch.nn.Linear(d_model * d_input + d_model * d_channel, d_output)



    def forward(self, x,stage):
        '''
        Args:
            audio_x: tensor of shape (batch_size, audio_in)
            video_x: tensor of shape (batch_size, video_in)
            text_x: tensor of shape (batch_size, sequence_len, text_in)
        '''
        stage = stage
        audio_h, self.score_input, self.input_to_gather, _ ,_ ,_ ,_ = self.net1(x, stage)
        # video_h, self.score_channel, self.channel_to_gather, _, _, _, _ = self.net2(x, stage)
        # text_h = self.text_subnet(text_x)
        batch_size = audio_h.data.shape[0]

        # next we perform "tensor fusion", which is essentially appending 1s to the tensors and take Kronecker product
        if audio_h.is_cuda:
            DTYPE = torch.cuda.FloatTensor
        else:
            DTYPE = torch.FloatTensor

        _audio_h = torch.cat((Variable(torch.ones(batch_size, 1).type(DTYPE), requires_grad=False), audio_h), dim=1)
        # _video_h = torch.cat((Variable(torch.ones(batch_size, 1).type(DTYPE), requires_grad=False), video_h), dim=1)
        # _text_h = torch.cat((Variable(torch.ones(batch_size, 1).type(DTYPE), requires_grad=False), text_h), dim=1)

        # _audio_h has shape (batch_size, audio_in + 1), _video_h has shape (batch_size, _video_in + 1)
        # we want to perform outer product between the two batch, hence we unsqueenze them to get
        # (batch_size, audio_in + 1, 1) X (batch_size, 1, video_in + 1)
        # fusion_tensor will have shape (batch_size, audio_in + 1, video_in + 1)
        # fusion_tensor = torch.bmm(_audio_h.unsqueeze(2), _video_h.unsqueeze(1)).view(batch_size, -1)
        # fusion_tensor = _audio_h.unsqueeze(2).view(batch_size, -1)
        fusion_tensor = _audio_h.view(batch_size, -1)

        # next we do kronecker product between fusion_tensor and _text_h. This is even trickier
        # we have to reshape the fusion tensor during the computation
        # in the end we don't keep the 3-D tensor, instead we flatten it
        # fusion_tensor = fusion_tensor.view(-1, (self.audio_hidden + 1) * (self.video_hidden + 1), 1)
        # fusion_tensor = torch.bmm(fusion_tensor, _text_h.unsqueeze(1)).view(batch_size, -1)

        post_fusion_dropped = self.post_fusion_dropout(fusion_tensor)
        post_fusion_y_1 = F.relu(self.post_fusion_layer_1(post_fusion_dropped))
        post_fusion_y_2 = F.relu(self.post_fusion_layer_2(post_fusion_y_1))
        # post_fusion_y_3 = F.sigmoid(self.post_fusion_layer_3(post_fusion_y_2))
        output = F.softmax(self.post_fusion_layer_3(post_fusion_y_2))
        # output = post_fusion_y_3 * self.output_range + self.output_shift
        score_input = self.score_input
        score_channel = 0
        input_to_gather = self.input_to_gather
        channel_to_gather = 0

        # return output, post_fusion_y_1, score_input, score_channel,input_to_gather, channel_to_gather, post_fusion_y_2

        return audio_h, post_fusion_y_1, score_input, score_channel, input_to_gather, channel_to_gather, post_fusion_y_2


























#
# if __name__ == '__main__':
#
#     # jt.flags.use_cuda=1
#     # input_points = init.gauss((16, 3, 1024), dtype='float32')  # B, D, N
#     # input_points = np.random.randn((16, 3, 1024))
#     DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 选择设备 CPU or GPU
#     print(f'use device: {DEVICE}')
#     input_points = np.random.uniform(size=(300, 13, 100))
#     DATA_LEN = 12  # 训练集样本数量
#     d_input = 100  # 时间部数量
#     d_channel = 18 # 时间序列维度
#     d_output = 2  # 分类类别
#     dropout = 0.2
#     pe = True
#     mask = True
#
#     EPOCH, BATCH_SIZE, LR, d_model, d_hidden, q, v, h, N, d_fusion, post_fusion_dim = 300, 200, 1e-3, 256, 512, 2, 2, 2, 2, 200, 200  # 2
#     input_points = np.random.uniform(size=(16, 3, 128))
#     # input_tensor = tf.convert_to_tensor(input_points)
#     input_tensor = torch.tensor(input_points).to(DEVICE)
#     net = TFN(d_model=d_model, d_input=d_input, d_channel=d_channel, d_output=d_output,
#               d_hidden=d_hidden,
#               q=q, v=v, h=h, N=N, d_fusion=d_fusion, post_fusion_dim=post_fusion_dim, dropout=dropout, pe=pe,
#               mask=mask, device=DEVICE).to(DEVICE)

    # network = Point_Transformer_Last()
    # network = TFN()
    # y_pre, _, _, _, _, _, _ = net(input_points.to(DEVICE),
    #                               'train')  ##########################################################################
    # y_pre, _, _, _, _, _, _ = net(input_tensor,'train')  ##########################################################################
    # out_logits = net(input_points)
    # print (out_logits.shape)