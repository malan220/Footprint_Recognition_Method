# @Time    : 2021/01/22 25:16
# @Author  : zc
# @FileName: oneDconvnet.py
import numpy as np
import torch
from torch import nn


class OneD_conv(nn.Module):
    def __init__(self, conv_only=False, bn=True, init_weight=False):
        super(OneD_conv, self).__init__()

        # Make layers
        self.features = self._make_conv_bn_layers() if bn else self._make_conv_layers()
        if not conv_only:
            self.fc = self._make_fc_layers()

        # Initialize weights
        if init_weight:
            self._initialize_weights()

        self.conv_only = conv_only


    def forward(self, x):
        x = self.features(x)
        if not self.conv_only:
           x = self.fc(x)
        return x

    def _make_fc_layers(self):
        fc = nn.Sequential(


            nn.Linear(352,50),
            nn.ELU()
        )
        return fc

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def _make_conv_bn_layers(self):
        conv = nn.Sequential(
            nn.Conv1d(1, 8, 3, stride=1, padding=0),

            nn.SELU(),

            nn.Conv1d(8, 16, 3, stride=1, padding=0),

            nn.SELU(),

            nn.MaxPool1d(2),

            nn.Conv1d(16, 16, 3, stride=1, padding=0),

            nn.SELU(),

            nn.Conv1d(16, 16, 3, stride=1, padding=0),

            nn.SELU(),

            nn.MaxPool1d(2),
            nn.Flatten()




        )
        return conv
class Fc(nn.Module):
    def __init__(self):
        super(Fc, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(900,100),
            nn.Dropout(0.5),
            nn.Linear(100,20),
            nn.Dropout(0.5),
            nn.Linear(20,2),


            )


    def forward(self, x):
        x = self.fc(x)
        return x


        return fc

module = OneD_conv()
x=torch.rand(5,100,18)
#取三维张量的每一行
#a = torch.arange(0, 1800).reshape(1,100,18)
# print(a)
# b = a.index_select(2, torch.tensor([1]))
# print(b)
#
# c =b.reshape(1,100)
# print(c)
# print(c.shape)
fc = Fc()
record = []
for i in range(x.size(2)):
    b = x.permute(0, 2, 1)
    c = b.index_select(1, torch.tensor([i]))
    # module = modulelist[i]
    d = module(c)

    # 行拼接
    if i == 0:
        result = d
    else:
        result = torch.cat((result, d), axis=1)

pred = fc(result)






