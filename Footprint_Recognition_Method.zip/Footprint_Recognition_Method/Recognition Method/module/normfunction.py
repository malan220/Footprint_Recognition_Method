from numpy import *
import numpy as np
from numpy import random as rd
import numpy as np

import torch
from torch import nn
from torch.nn import Module

def Euclidean_Distance(mat1, mat2):
    mat20 = mat2.permute(0, 2, 1)
    mat11 = torch.sum(mat1 ** 2, dim=2, keepdims=True)
    # mat11 = (mat1**2).sum(axis=1, keepdims=True)
    mat22 = torch.sum(mat20 ** 2, dim=2, keepdims=True)
    value_output = (mat11 + mat22 - 2 * torch.matmul(mat1, mat2)) ** 0.5
    return value_output

# def Euclidean_Distance3(mat1, mat2):
#     a = torch.tensor([[1, 2, 3], [-1, 1, 4]], dtype=torch.float)
#     print(a.norm(p=1))  # 计算各个元素绝对值的和
#     print(torch.norm(a, p=1, dim=1))  # 指定维度，横向计算各个元素绝对值的和
#     print(torch.norm(a, p=1, dim=0))  # 纵向计算各个元素绝对值的和



def Manhattan_Distance(mat1, mat2):
    # aa = torch.randint(0, 10, (100, 567, 16))
    # bb = torch.randint(0, 10, (100, 16, 567))
    # mat20 = mat2.permute(0, 2, 1)
    mat10 = torch.unsqueeze(mat1.permute(0, 2, 1), -1)
    mat20 = torch.unsqueeze(mat2, -1)
    aa3 = torch.sub(mat10, mat20.permute(0, 1, 3, 2))
    aa6 = torch.norm(aa3, p=1, dim=1, keepdim=False)
    # aa4 = torch.abs(aa3)
    # value_output = torch.sum(aa4, 1, keepdim=False)
    return aa6

def Chebyshev_Distance(mat1, mat2):
    # aa = torch.randint(0, 10, (100, 567, 16))
    # bb = torch.randint(0, 10, (100, 16, 567))
    # mat20 = mat2.permute(0, 2, 1)
    mat10 = torch.unsqueeze(mat1.permute(0, 2, 1), -1)
    mat20 = torch.unsqueeze(mat2, -1)
    aa3 = torch.sub(mat10, mat20.permute(0, 1, 3, 2))
    aa6 = torch.norm(aa3, p=0, dim=1, keepdim=False)
    # aa4 = torch.abs(aa3)
    # value_output = torch.sum(aa4, 1, keepdim=False)
    return aa6


def Chebyshev_Distance1(mat1, mat2):
    mat10 = torch.unsqueeze(mat1.permute(0, 2, 1), -1)
    mat20 = torch.unsqueeze(mat2, -1)
    aa3 = torch.sub(mat10, mat20.permute(0, 1, 3, 2))
    aa4 = torch.abs(aa3)
    # value_output = torch.max(aa4, dim=1)
    value_output = torch.max(aa4, 1, keepdim=False)
    # value_output = aa4.max(1)
    return value_output
    # value_output[i0][i][j] = abs((mat1[i0][i][:] - mat2[i0][j][:])).max()


def Cos_Distance(mat1, mat2):
    # aa = torch.randint(0, 10, (100, 567, 16))
    # bb = torch.randint(0, 10, (100, 16, 567))
    # mat20 = mat2.permute(0, 2, 1)
    # mat10 = torch.unsqueeze(mat1.permute(0, 2, 1), -1)
    # mat20 = torch.unsqueeze(mat2, -1)
    mat10 = mat1
    mat20 = mat2
    aa3 = torch.matmul(mat10, mat20)
    aa5 = torch.norm(mat10, p=2, dim=2, keepdim=False)
    aa5 = torch.unsqueeze(aa5, -1)
    aa6 = torch.norm(mat20, p=2, dim=1, keepdim=False)
    aa6 = torch.unsqueeze(aa6, -1)
    aa6 = aa6.permute(0, 2, 1)
    aa7 = aa3/torch.matmul(aa5, aa6)
    # aa4 = torch.abs(aa3)
    # value_output = torch.sum(aa4, 1, keepdim=False)
    return aa7



if __name__ == '__main__':

    # aa = torch.randn(0, 10, (100, 567, 16))
    # aa2 = torch.randn(0, 10, (100, 16, 567))
    aa = torch.randn(100, 567, 16)
    aa2 = torch.randn(100, 16, 567)
    # a1 = Euclidean_Distance(aa, aa2)
    # a2 = Manhattan_Distance(aa, aa2)
    # a3 = Chebyshev_Distance(aa, aa2)
    a3 = Cos_Distance(aa, aa2)


